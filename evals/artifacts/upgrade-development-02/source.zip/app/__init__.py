"""CoursePilot AI agent service."""
