"""One-shot migration-role grants. Never executed by the runtime account."""
import os

import psycopg
from psycopg import sql
from psycopg.rows import dict_row
from langgraph.checkpoint.postgres import PostgresSaver

from app.config import get_settings


def main() -> None:
    settings = get_settings()
    dsn = (settings.migration_database_url or settings.database_url).replace("postgresql+asyncpg://", "postgresql://")
    role = "coursepilot_agent"
    password = os.environ["AGENT_DB_PASSWORD"]
    with psycopg.connect(dsn, autocommit=True, row_factory=dict_row) as connection:
        connection.execute("CREATE SCHEMA IF NOT EXISTS agent")
        connection.execute("SET search_path TO agent, public")
        PostgresSaver(connection).setup()
        if not connection.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (role,)).fetchone():
            connection.execute(sql.SQL("CREATE ROLE {} LOGIN").format(sql.Identifier(role)))
        connection.execute(sql.SQL("ALTER ROLE {} NOSUPERUSER NOCREATEDB NOCREATEROLE PASSWORD {}").format(
            sql.Identifier(role), sql.Literal(password)))
        connection.execute(sql.SQL("GRANT USAGE ON SCHEMA public, agent TO {}").format(sql.Identifier(role)))
        connection.execute(sql.SQL("GRANT SELECT ON ALL TABLES IN SCHEMA public TO {}").format(sql.Identifier(role)))
        connection.execute(sql.SQL("GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA agent TO {}").format(sql.Identifier(role)))
        connection.execute(sql.SQL("GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA agent TO {}").format(sql.Identifier(role)))
        connection.execute(sql.SQL("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO {}").format(sql.Identifier(role)))
        connection.execute(sql.SQL("ALTER DEFAULT PRIVILEGES IN SCHEMA agent GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO {}").format(sql.Identifier(role)))


if __name__ == "__main__":
    main()
